---
name: Enterprise IT Trainee Portfolio
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#434655'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#005e6e'
  on-tertiary: '#ffffff'
  tertiary-container: '#00788c'
  on-tertiary-container: '#d7f6ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system establishes a high-trust, structured, and modern professional identity tailored for early-career IT practitioners, ServiceNow administrators, and systems engineers. 

The aesthetic is grounded in **Corporate Minimal Modernism**—clean, authoritative, and systematically arranged. It deliberately avoids flashy, non-standard animations in favor of precision, high legibility, and architectural rigor. The emotional takeaway for hiring managers and technical recruiters must be reliability, technical competence, attention to detail, and operational readiness.

Key aesthetic principles:
- **Systematic Structure:** Heavy reliance on clear visual hierarchy, consistent spacing multiples, and semantic HTML structure.
- **Enterprise Credibility:** Deep slate navies and purposeful technical blues emulate trusted enterprise tools (ServiceNow, Jira, AWS, Azure).
- **Engineered Restraint:** Clean off-white canvases punctuated by subtle cyan data accents, ensuring information density remains comfortable rather than cluttered.

## Colors

The palette balances deep authority with crisp technical precision:

- **Primary (`#2563EB`):** Tech blue used for primary calls-to-action, active indicators, focus rings, and primary links.
- **Secondary (`#0F172A` / `#1E293B`):** Deep navy and slate. Used for high-contrast headers, dark surface accents (such as terminal-style blocks or sidebars), and key branding elements.
- **Tertiary Accent (`#06B6D4` / `#0891B2`):** Subtle cyan used sparingly for certification badges, status indicators (e.g., "Available for hire", "In Progress"), code accents, and metrics.
- **Canvas & Backgrounds (`#F8FAFC`, `#FFFFFF`):** Crisp, clinical off-white canvas with pure white elevated cards to establish soft optical separation without harsh contrasts.
- **Borders & Rules (`#E2E8F0`):** Subtle slate boundary lines that keep data grids, cards, and sections organized.
- **Text & Content (`#0F172A`, `#1E293B`, `#475569`):** High-readability charcoal and slate for primary headings, body copy, and secondary meta-labels. Never use pure `#000000`.

## Typography

The typography relies on **Inter**, falling back gracefully to system sans-serif font stacks (`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`). 

Type rules:
- **Hierarchy:** Strict vertical cadence. Maintain tabular alignment where data or stats are presented.
- **Headlines:** Use tighter letter spacing (`-0.025em` to `-0.01em`) and bold/extrabold weights to convey decisive enterprise presence.
- **Labels & Tags:** Uppercase or small title case with slight positive letter spacing (`0.02em` to `0.05em`) for skills, status labels, certification tags, and metadata timestamps.
- **Code & IDs:** Fall back to monospace system fonts (`ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas`) for ServiceNow instance roles, ticket numbers, syntax snippets, and credentials.

## Layout & Spacing

The layout is built on a responsive, container-based 12-column grid system paired with CSS Flexbox for micro-layouts:

- **Desktop (1024px+):** Fixed maximum container width of `1140px` centered with automatic horizontal margins. Employs a multi-column asymmetric split: a sticky 4-column profile/skills rail paired with an 8-column main experience, certifications, and portfolio track.
- **Tablet (768px - 1023px):** 8-column grid with `1.5rem` gutters. Profile details collapse to top banner layout; project cards display as 2-column grids.
- **Mobile (< 768px):** Single-column layout with `1rem` margins and `1rem` gutters. All horizontal arrangements wrap gracefully to column orientation.
- **Vertical Rhythm:** Sections are separated consistently with `space-xl` (2.5rem) or `4rem` spacers to preserve clarity and prevent cognitive fatigue.

## Elevation & Depth

Depth is expressed through low-contrast borders combined with ultra-subtle, ambient drop shadows:

- **Level 0 (Base Canvas):** `#F8FAFC`. Background for entire viewport. No shadow.
- **Level 1 (Cards, Sections, Table Rows):** `#FFFFFF` surface with a crisp `1px solid #E2E8F0` border and an ambient soft shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.05), 0 1px 2px -1px rgba(15, 23, 42, 0.05)`.
- **Level 2 (Hover States, Interactive Cards):** `0 4px 12px -2px rgba(15, 23, 42, 0.08), 0 2px 6px -2px rgba(15, 23, 42, 0.04)`. Card translates `-2px` along the Y-axis with a subtle border transition to `#CBD5E1`.
- **Level 3 (Modals, Flyouts, Popovers):** `0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.06)`. Used for contact popovers or full credential previews.

## Shapes

The design uses a **Soft (Level 1)** shape radius:
- Base elements (buttons, form inputs, skill badges, cards): `0.375rem` (6px) to `0.5rem` (8px).
- Pill shapes are reserved exclusively for status indicators (e.g., `Available for full-time roles` or `CSA Certified`) to create functional distinction from rectangular cards.
- Avatar / Profile image: Rounded-full circular framing or soft-square with a `0.75rem` radius and a `2px` slate border.

## Components

### Buttons
- **Primary:** Solid `#2563EB` background with white text, font weight 600, padding `0.625rem 1.25rem`, radius `0.375rem`. Hover state transitions background to `#1D4ED8`. Focus outline: 2px solid `#2563EB` with 2px offset.
- **Secondary:** White background with `#0F172A` text, `1px solid #E2E8F0` border. Hover changes background to `#F1F5F9`.
- **Ghost/Link:** Transparent background, `#2563EB` text, underlined on hover.

### Chips & Badges
- **Technical Skill Badges:** Background `#F1F5F9`, text `#334155`, `1px solid #E2E8F0`, padding `0.25rem 0.625rem`, radius `0.25rem`, font size `12px`, font weight 500.
- **ServiceNow / Credential Badges:** Background `#ECFEFF` (cyan tint), text `#0E7490`, border `1px solid #A5F3FC`, font weight 600. Includes a tiny pulse dot for active certifications.

### Cards
- **Project & Experience Cards:** `#FFFFFF` background, `1px solid #E2E8F0` border, `1.5rem` internal padding, `0.5rem` border radius. 
- Includes an internal header zone (role title, company/project name, date range in `#64748B`), bulleted achievement points, and a footer row of associated technology chips.

### Form Inputs
- Background `#FFFFFF`, border `1px solid #CBD5E1`, text `#0F172A`, placeholder `#94A3B8`.
- Focus state: border color `#2563EB`, box-shadow `0 0 0 3px rgba(37, 99, 235, 0.15)`, transition `border-color 0.15s ease, box-shadow 0.15s ease`.

### Timelines & Work Experience
- Vertical line `2px solid #E2E8F0` running down the left axis with a node circle (`#2563EB` center, `#DBEAFE` 4px outer ring) marking each role, project milestone, or academic milestone.

### Code & Config Previews
- Terminal/script card styled with `#0F172A` background, `#F8FAFC` text, and `#06B6D4` syntax highlights for displaying sample ServiceNow Client Scripts, Business Rules, or automated flows.